<?php

namespace Illuminate\Contracts\Debug;

interface ShouldntReport
{
    //
}
